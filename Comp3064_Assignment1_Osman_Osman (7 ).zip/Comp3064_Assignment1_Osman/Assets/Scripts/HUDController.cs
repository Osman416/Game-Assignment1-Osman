﻿/*
Name: Osman Osman
I.D: 100962928
SrcName: HUD Controller
*/
using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class HUDController : MonoBehaviour {

	[SerializeField]
	Text pointsLabel = null;
	[SerializeField]
	Text healthLabel = null;

	//new
	[SerializeField]
	Text startGameLabel = null;
	[SerializeField]
	Button restartBtn = null;
	[SerializeField]
	Text gameOverLabel = null;
	[SerializeField]
	GameObject player = null;
	[SerializeField]
	Text highScore = null;

	public void UpdatePoints(){

		pointsLabel.text = "Points: " + Player.Instance.Points;

	}

	public void UpdateHealth(){

		healthLabel.text = "Health: " + Player.Instance.Health;
	}

	// Use this for initialization
	void Start () {
		Player.Instance.HUD = this;

		//hides health and points labels
		pointsLabel.gameObject.SetActive(false);
		healthLabel.gameObject.SetActive(false);

		//hides player
		player.SetActive(false);

		//displays startGame label, and hides GameOver and highscore
		startGameLabel.gameObject.SetActive(true);
		gameOverLabel.gameObject.SetActive(false);
		highScore.gameObject.SetActive (false);


		//displays start/restart button
		restartBtn.gameObject.SetActive(true);

	}

	public void GameOver(){

		//hide health and points labels
		pointsLabel.gameObject.SetActive(false);
		healthLabel.gameObject.SetActive(false);

		//hide player
		player.SetActive(false);

		//display GameOver label , and high score
		gameOverLabel.gameObject.SetActive(true);
		highScore.gameObject.SetActive (true);
		highScore.text = "High Score: " + Player.Instance.HighScore;

		//displays restart button
		restartBtn.gameObject.SetActive(true);

	}

	//when restart/start buttton is clicked
	public void RestartGame(){

		//showing point and health labels
		pointsLabel.gameObject.SetActive(true);
		healthLabel.gameObject.SetActive(true);
		Player.Instance.Points = 0;
		Player.Instance.Health = 100;

		//hide highscore label
		highScore.gameObject.SetActive (false);

		//show player
		player.SetActive(true);

		//hide gameover label and start game label
		gameOverLabel.gameObject.SetActive(false);
		startGameLabel.gameObject.SetActive(false);

		//hide restart button
		restartBtn.gameObject.SetActive(false);

	}
}
