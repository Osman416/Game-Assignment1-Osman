﻿/*
Name: Osman Osman
I.D: 100962928
SrcName: Explosion Controller (for explosion animation)
*/
using UnityEngine;
using System.Collections;

public class ExplosionController : MonoBehaviour {

	//
	void Explode() {
		var explode = GetComponent<ParticleSystem>();
		explode.Play();
		Destroy(gameObject, explode.duration);
	}

	// explodes after a time delay
	public float timeDelay;

	void Start() {
		Invoke("explosion", timeDelay);
		var explode = GetComponent<ParticleSystem>();
		explode.Play();
		Destroy(gameObject, explode.duration);
	}

	// explodes on impact.
	void OnCollisionEnter(Collision other) {
		Explode();
	}

	/*	
	public void End(){

		Destroy (gameObject);

	}*/

}
