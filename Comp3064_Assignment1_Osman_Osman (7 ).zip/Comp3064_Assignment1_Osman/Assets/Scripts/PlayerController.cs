﻿/*
Name: Osman Osman
I.D: 100962928
SrcName: Player Controller (controls the player)
*/
using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {

	[SerializeField]
	private float speed = 20;

	private Transform _transform;
	private Vector3 _currentPosition;
	private float _playerInput;


	// Use this for initialization
	void Start () {
		_transform = gameObject.GetComponent<Transform>();
		_currentPosition = _transform.position;


	}
	
	// Update is called once per frame
	void FixedUpdate () {

		_currentPosition = _transform.position;



		if (Input.GetKey (KeyCode.LeftArrow)) {
			_transform.position += Vector3.left * speed
			* Time.deltaTime;
		}

		if (Input.GetKey (KeyCode.RightArrow)) {
			_transform.position += Vector3.right * speed
				* Time.deltaTime;
		}

		if (Input.GetKey (KeyCode.UpArrow)) {
			_transform.position += Vector3.up * speed
				* Time.deltaTime;
		}

		if (Input.GetKey (KeyCode.DownArrow)) {
			_transform.position += Vector3.down * speed
				* Time.deltaTime;
		}

		//fix bounds
		checkBounds ();
		_transform.position = _currentPosition;
	}

	private void checkBounds(){

		_currentPosition = _transform.position;

		if (_currentPosition.y < -4.4f) {
			_currentPosition.y = -4.4f;
		}
		if (_currentPosition.y > 4.4f) {
			_currentPosition.y = 4.4f;
		}

		else if (_currentPosition.x < -10f) {
			_currentPosition.x = -10f;
		}
		else if (_currentPosition.x > 10.5f) {
			_currentPosition.x = 10.5f;
		}


	}
}
