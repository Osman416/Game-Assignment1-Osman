﻿/*
Name: Osman Osman
I.D: 100962928
SrcName: Enemy Shooting (allows enemy to shoot)
*/
using UnityEngine;
using System.Collections;

public class EnemyShoot : MonoBehaviour {

	public Vector3 bulletpos = new Vector3(0, 1f, 0);

	public GameObject bulletpf;
	int bulletLayer;

	public float shootDelay = 0.2f;
	float timer = 0;

	Transform Player;


	void Start() {
		bulletLayer = gameObject.layer;
	}

	// Update is called once per frame
	void Update () {
		
			if(Player == null) {
			
				// find player
				GameObject shoot = GameObject.FindWithTag ("Player");

				if(shoot != null) {
					Player = shoot.transform;
				}

			}


		timer -= Time.deltaTime;

		//shoot if player is near and if player is not null 
		if( timer <= 0 && bulletpf != null && Player != null && Vector3.Distance(transform.position, Player.position) < 10) {

			// Shoot Bullet
			Debug.Log ("enemy shot bullet");
			timer = shootDelay;

			Vector3 set = transform.rotation * bulletpos;

			GameObject bulletGO = (GameObject)Instantiate(bulletpf, transform.position + set, transform.rotation);
			bulletGO.layer = bulletLayer;
		}
	}
}