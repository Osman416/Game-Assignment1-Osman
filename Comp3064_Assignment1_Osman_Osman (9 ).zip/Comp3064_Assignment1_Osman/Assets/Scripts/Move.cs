﻿/*
Name: Osman Osman
I.D: 100962928
SrcName: Move Forward (for bullet)
*/
using UnityEngine;
using System.Collections;

public class Move : MonoBehaviour {

	public float maxSpeed = 5f;

	// Update is called once per frame
	//
	void Update () {
		Vector3 pos = transform.position;

		Vector3 velocity = new Vector3(0, maxSpeed * Time.deltaTime, 0);

		pos += transform.rotation * velocity;

		//makes bullet move on a straight path
		transform.position = pos;
	}

}
