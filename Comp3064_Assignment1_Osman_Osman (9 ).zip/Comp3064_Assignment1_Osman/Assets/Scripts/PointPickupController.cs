﻿/*
Name: Osman Osman
I.D: 100962928
SrcName: PointPickupController (controls pickups)
*/
using UnityEngine;
using System.Collections;

public class PointPickupController : MonoBehaviour {

	[SerializeField]
	//private float speed;

		private Vector2 speed = Vector2.zero;

	private Transform _transform;
	private Vector2 _currentPosition;

	private float minY = -4;
	private float maxY = 4;

		public float VerticalSpeed = 5f; //Speed
	public float Dir = 1f;//Direction (up or down)
	private int direction = -3;

	public AudioClip Hit11;

	void OnTriggerEnter2D (Collider2D other)
	{
		if (other.gameObject.tag == "Player")
		{

			Vector3 NewPos = new Vector3 (transform.position.x, transform.position.y + Random.Range (minY, maxY) + ((VerticalSpeed * Time.deltaTime) * Dir), transform.position.z);
			transform.position = NewPos;
			gameObject.GetComponent<AudioSource> ().Play ();

			Reset ();

		}
	}

	// Use this for initialization
	void Start () {
		_transform = gameObject.GetComponent<Transform>();
		_currentPosition = _transform.position;
		Reset ();

			Dir = Random.value > 0.5f ? 1f : -1f; //sets Dir to start randomly
			float StartY = Random.Range (minY, maxY);//get random value b/w min and max
			transform.position = new Vector3(transform.position.x, StartY, transform.position.z);//set position to random value b/w min and max.

		GetComponent<AudioSource> ().playOnAwake = false;
		GetComponent<AudioSource> ().clip = Hit11;

	}

	// Update is called once per frame
	void FixedUpdate () {
		_currentPosition = _transform.position;

		Vector2 currSpeed = new Vector2 (speed.x *direction, speed.y*0);
		_currentPosition -= currSpeed;
		_transform.position = _currentPosition;


		if (_currentPosition.x <= -12) {
			Reset ();
		

			//check if y position is more than max or les than min.
			if (transform.position.y > maxY)
				Dir = -1f;
			else if (transform.position.y < minY)
				Dir = 1f;

			//Calculate new position
			Vector3 NewPos = new Vector3 (transform.position.x, transform.position.y + Random.Range (minY, maxY) + ((VerticalSpeed * Time.deltaTime) * Dir), transform.position.z);
			transform.position = NewPos;
		
		}
	}

	private void Reset(){

			direction = 3;
			_transform.localScale = new Vector2 (direction, 3);
			_currentPosition = new Vector2 (direction*10f, 0f);
			_transform.position = _currentPosition;

	}

}