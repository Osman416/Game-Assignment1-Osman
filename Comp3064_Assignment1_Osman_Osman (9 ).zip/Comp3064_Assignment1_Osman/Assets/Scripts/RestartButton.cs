﻿/*
Name: Osman Osman
I.D: 100962928
SrcName: Restart Button (to start or restart game)
*/
using UnityEngine;
using System.Collections;

public class RestartButton : MonoBehaviour {

	// shows Restart Game HUD
	public void RestartGame(){


	}
}