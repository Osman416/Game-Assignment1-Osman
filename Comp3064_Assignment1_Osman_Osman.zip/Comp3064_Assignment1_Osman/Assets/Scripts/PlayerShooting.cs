﻿using UnityEngine;
using UnityEngine;
using System.Collections;

public class PlayerShooting : MonoBehaviour {
	public AudioClip laser;
	public Vector3 bulletOffset = new Vector3(0, 1f, 0);

	public GameObject bulletpf;
	int bulletLayer;
	GameObject explosion = null;
	public float fireDelay = 0.02f;
	float cooldownTimer = 0;
	public AudioClip Hit;

	void OnTriggerEnter2D(Collider2D other){
		if (other.gameObject.tag == "bullet") {
		//	Player.Instance.Health = Player.Instance.Health - 10;
		//	PlayerShooting sp = 
		//		other.gameObject.GetComponent<PlayerShooting> ();
		//	gameObject.GetComponent<AudioSource> ().Play ();
		//	GetComponent<AudioSource> ().playOnAwake = false;
		//	GetComponent<AudioSource> ().clip = Hit;

		//	GameObject e = Instantiate(explosion);
		//	e.transform.position = other.gameObject.transform.position;
		}
	}

	void Start() {
		bulletLayer = gameObject.layer;
	}

	// Update is called once per frame
	void Update () {
		cooldownTimer -= Time.deltaTime;

		if( Input.GetButton("Fire1")|| Input.GetKeyDown(KeyCode.Space) && cooldownTimer <= 0 ) {
			// SHOOT!
			cooldownTimer = fireDelay;

			Vector3 offset = transform.rotation * bulletOffset;

			gameObject.GetComponent<AudioSource> ().Play ();
			GetComponent<AudioSource> ().playOnAwake = false;
			GetComponent<AudioSource> ().clip = laser;

			GameObject bulletGO = (GameObject)Instantiate(bulletpf, transform.position + offset, transform.rotation);
			bulletGO.layer = bulletLayer;
		}
	}
}
