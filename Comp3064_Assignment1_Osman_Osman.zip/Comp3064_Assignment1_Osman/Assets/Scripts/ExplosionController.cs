﻿using UnityEngine;
using System.Collections;

public class ExplosionController : MonoBehaviour {

/*	public void End(){

		Destroy (gameObject);

	}*/

	void Explode() {
		var exp = GetComponent<ParticleSystem>();
		exp.Play();
		Destroy(gameObject, exp.duration);
	}

	// Grenade explodes after a time delay.
	public float fuseTime;

	void Start() {
		Invoke("Explode", fuseTime);
		var exp = GetComponent<ParticleSystem>();
		exp.Play();
		Destroy(gameObject, exp.duration);
	}

	// Grenade explodes on impact.
	void OnCollisionEnter(Collision coll) {
		Explode();
	}

	/*
	// On the explosion object.
	void Start() {
		var exp = GetComponent<ParticleSystem>();
		exp.Play();
		Destroy(gameObject, exp.duration);
	}*/

	/*
	// Possible projectile script.
	public GameObject explosionPrefab;

	void Update() {
		RaycastHit hit;

		if (Physics.Raycast (Camera.main.ScreenPointToRay (Input.mousePosition), out hit)) {
			Instantiate (explosionPrefab, hit.point, Quaternion.identity);
		}
	}*/

}
