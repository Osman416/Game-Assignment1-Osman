﻿/*
Name: Osman Osman
I.D: 100962928
SrcName: Player Collider (for plyer collisions)
*/
using UnityEngine;
using System.Collections;

public class PlayerCollider : MonoBehaviour {

	[SerializeField]
	GameObject explosion = null;


	private float speed;

	private Transform _transform;
	private Vector2 _currentPosition;

	private float minY = -4.5f;//lowest y value
	private float maxY = 4.5f;//highest y value

	public GameObject enemy;
	public GameObject pointOrb;
	public AudioSource explode;



	void Start() {
		//creates 3 clones of enemy
		for (int i = 0; i < 3; i++) {
			Instantiate(enemy);
		}
			
	}

	void OnTriggerEnter2D(Collider2D other){

		if (other.gameObject.tag == "pointOrb") {

			Debug.Log ("points picked up");
			//update health
			Player.Instance.Health = Player.Instance.Health + 10;

			PointPickupController s = 
				other.gameObject.GetComponent<PointPickupController> ();


		} else if (other.gameObject.tag == "enemy") {
			Debug.Log ("Collision with enemy plane");
			//Update health
			Player.Instance.Health = Player.Instance.Health - 10;

			EnemyController sp = 
				other.gameObject.GetComponent<EnemyController> ();

			//Show explosion
			GameObject e = Instantiate (explosion);
			e.transform.position = other.gameObject.transform.position;
			//Play explosion sound
			AudioSource asrc = gameObject.GetComponent<AudioSource> ();
			if (asrc != null) {
				asrc.Play ();
			}

			if (sp != null) {
				sp.Reset ();
			}

		} else if (other.gameObject.tag == "Ebullet") {
			Debug.Log ("shot by enemy");
			//Update health
			Player.Instance.Health = Player.Instance.Health - 5;

			EnemyController sp = 
				other.gameObject.GetComponent<EnemyController> ();

			//Show explosion
			GameObject e = Instantiate (explosion);
			e.transform.position = other.gameObject.transform.position;
			//Play explosion sound
			AudioSource asrc = gameObject.GetComponent<AudioSource> ();
			if (asrc != null) {
				asrc.Play ();
			}

			if (sp != null) {
				sp.Reset ();
			}
		}if (other.gameObject.tag == "healthOrb") {

			Debug.Log ("health picked up");
			//update health
			Player.Instance.Health = Player.Instance.Health + 10;

			PointPickupController s = 
				other.gameObject.GetComponent<PointPickupController> ();

		}


	}


	private void Reset(){
		float ypos = Random.Range (minY, maxY);
		float xpos = Random.Range (5.3f, 12f);
		_currentPosition = new Vector2 (xpos, ypos);
		_transform.position = _currentPosition;

	}

}