﻿using UnityEngine;
using System.Collections;

public class PlayerCollider : MonoBehaviour {
	
	[SerializeField]
	GameObject explosion = null;


	private float speed;

	private Transform _transform;
	private Vector2 _currentPosition;

	private float minY = -4f;
	private float maxY = 4f;

	public GameObject enemy;
	public GameObject pointOrb;

	void Start() {
		for (int i = 0; i < 2; i++) {
			Instantiate(enemy);
		}

		for (int i = 0; i < 0; i++) {
			Instantiate(pointOrb);
		}

	}

	// Update is called once per frame
	void FixedUpdate () {
		//speed = 25;
		//float moveHorizontal = Input.GetAxis("Horizontal");
		//float moveVertical = Input.GetAxis("Vertical");
		///float ypos = Random.Range (minY, maxY);
		//float xpos = Random.Range (5.3f, 12f);
		//Vector3 movement = new Vector3 (xpos,0, ypos);
		//rb.AddForce (movement * speed);


	}

	void OnTriggerEnter2D(Collider2D other){

		if (other.gameObject.tag == "pointOrb") {

			Debug.Log ("points picked up");
			Player.Instance.Points++;
			//Reset (other.gameObject);
			//PointPickupController.Reset ();

			PointPickupController s = 
				other.gameObject.GetComponent<PointPickupController> ();

		//	float ypos = Random.Range (minY, maxY);
		//	float xpos = Random.Range (5.3f, 12f);
		//	_currentPosition = new Vector2 (xpos, ypos);
		//	_transform.position = _currentPosition;

		} else if(other.gameObject.tag=="enemy"){
			Debug.Log ("Collision with enemy plane");
			//Update health
			Player.Instance.Health = Player.Instance.Health - 10;

			EnemyController sp = 
				other.gameObject.GetComponent<EnemyController> ();

			//Show explosion
			GameObject e = Instantiate(explosion);
			e.transform.position = other.gameObject.transform.position;
			//Play explosion sound
			AudioSource asrc = gameObject.GetComponent<AudioSource> ();
			if (asrc != null) {
				asrc.Play ();
			}

			if (sp != null) {
				sp.Reset ();
			}

		}

	}

	void OnCollisionEnter2D(Collision2D other){

		Debug.Log ("Collision");
		if (other.gameObject.tag == "enemy") {

	//		DontDestroyOnLoad(other.gameObject);
			//EnemyController.Reset (other.gameObject);
			//other.gameObject.transform.position = _currentPosition;
	//		other.gameObject.transform.position = new Vector2 (10, 12);
			//Vector3 (10, 10, 10);
			//other.gameObject.transform.rotation.z = 90;
			//other.gameObject.transform.r(0,0,90);
			//Awake ();
		}else if (other.gameObject.tag == "pointOrb") {

			//Player.Instance.Points++;
	//		DontDestroyOnLoad (other.gameObject);
		//	float ypos = Random.Range (-11f, -12f);
		//	float xpos = Random.Range (-11f, -12f);
	//		other.gameObject.transform.position = new Vector2 (11, 12);
			//other.gameObject.transform.position = _currentPosition;
			//Vector3 movement = new Vector3(10, 10, 10);
			//other.gameObject.transform.rotation.z = 90;
			//other.gameObject.transform.Rotate (0,0,90);
			//Awake ();
		}

	}
	private void Reset(){
		float ypos = Random.Range (minY, maxY);
		float xpos = Random.Range (5.3f, 12f);
		_currentPosition = new Vector2 (xpos, ypos);
		_transform.position = _currentPosition;
		//transform.Rotate (0,0,90);

	}
		
}
