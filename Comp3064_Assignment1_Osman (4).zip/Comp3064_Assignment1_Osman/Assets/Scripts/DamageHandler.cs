﻿using UnityEngine;
using System.Collections;

public class DamageHandler : MonoBehaviour {

	public int health = 1;

	public float invulnPeriod = 0;
	float invulnTimer = 0;
	int correctLayer;

	SpriteRenderer spriteRend;


	private Vector2 speed = Vector2.zero;

	private Transform _transform;
	private Vector2 _currentPosition; 

	public float minY = -4;//Set this to the lowest Y value you want the Item to move to.
	public float maxY = 4;//Set this to the highest Y value you want the Item to move to.
	public float VerticalSpeed = 5f; //Speed the Item will move vertically.
	public float Dir = 1f;//Direction the Item is moving, either up or down.

	//direction: positive when moving right, negative when moving left
	private int direction = -3;

	void Start() {
		correctLayer = gameObject.layer;

		// NOTE!  This only get the renderer on the parent object.
		// In other words, it doesn't work for children. I.E. "enemy01"
		spriteRend = GetComponent<SpriteRenderer>();

		if(spriteRend == null) {
			spriteRend = transform.GetComponentInChildren<SpriteRenderer>();

			if(spriteRend==null) {
				Debug.LogError("Object '"+gameObject.name+"' has no sprite renderer.");
			}
		}
	}

	void OnTriggerEnter2D(Collider2D other) {
		
		if(other.gameObject.tag == "Player"){
			
		health--;
	//	Die ();
	//	Reset ();

		}
		 if(invulnPeriod > 0) {
			invulnTimer = invulnPeriod;
			gameObject.layer = 1;
		//	Die ();
		//	Reset ();
		}
	}

	void Update() {

		if(invulnTimer > 0) {
			invulnTimer -= Time.deltaTime;

			if(invulnTimer <= 0) {
				gameObject.layer = correctLayer;
				if(spriteRend != null) {
					spriteRend.enabled = true;
				}
			}
			else {
				if(spriteRend != null) {
					spriteRend.enabled = !spriteRend.enabled;
				}
			}
		}

		if(health <= 0) {
			//EnemyController.Reset ();
			//Die();
			Reset ();
		}


	}

	void Die() {
		/*
		direction = 3;
		_transform.localScale = new Vector2 (direction, 3);
		_currentPosition = new Vector2 (direction*3f, 0f);
		_transform.position = _currentPosition;
*/

		DontDestroyOnLoad(gameObject);
		//DontDestroyOnLoad(gameObject);
		//EnemyController.Reset(gameObject);
	}

	void Reset(){
		direction = 3;
		_transform.localScale = new Vector2 (direction, 3);
		_currentPosition = new Vector2 (direction*3f, 0f);
		_transform.position = _currentPosition;
	}

}
