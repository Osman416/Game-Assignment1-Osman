﻿using UnityEngine;
using System.Collections;

public class PointPickupController : MonoBehaviour {

	[SerializeField]
	//private float speed;

		private Vector2 speed = Vector2.zero;

	private Transform _transform;
	private Vector2 _currentPosition;

	private float minY = -4;
	private float maxY = 4;

		public float VerticalSpeed = 5f; //Speed the Item will move vertically.
		public float Dir = 1f;//Direction the Item is moving, either up or down.
	private int direction = -3;

	public AudioClip Hit11;

	void OnTriggerEnter2D (Collider2D other)
	{
		if (other.gameObject.tag == "Player")
		{
			//Object.Destroy(this.gameObject);

			Vector3 NewPos = new Vector3 (transform.position.x, transform.position.y + Random.Range (minY, maxY) + ((VerticalSpeed * Time.deltaTime) * Dir), transform.position.z);
			transform.position = NewPos;
			gameObject.GetComponent<AudioSource> ().Play ();

			//Reset ();

			//Reset(gameObject.transform.position == NewPos);

			//	float ypos = Random.Range (minY, maxY);
			//	float xpos = Random.Range (5.3f, 12f);
			//	_currentPosition = new Vector2 (xpos, ypos);
			//	_transform.position = _currentPosition;

			//DontDestroyOnLoad ();

		}
	}

	// Use this for initialization
	void Start () {
		_transform = gameObject.GetComponent<Transform>();
		_currentPosition = _transform.position;
		Reset ();

			Dir = Random.value > 0.5f ? 1f : -1f; //Set Dir to start randomly either Up or Down.
			float StartY = Random.Range (minY, maxY);//Get a random value between Min and Max to start off at.
			transform.position = new Vector3(transform.position.x, StartY, transform.position.z);//Set item's Vertical position to a random value between Max and Min.

		GetComponent<AudioSource> ().playOnAwake = false;
		GetComponent<AudioSource> ().clip = Hit11;

	}

	// Update is called once per frame
	void FixedUpdate () {
		_currentPosition = _transform.position;

		Vector2 currSpeed = new Vector2 (speed.x *direction, speed.y*0);
		_currentPosition -= currSpeed;
		_transform.position = _currentPosition;

		//_currentPosition -= new Vector2 (speed.x *direction, speed.y*0); //(speed.x *direction, speed.y*0);
		//_transform.position = _currentPosition;

		if (_currentPosition.x <= -12) {
			Reset ();
		

			//Check to see if the Item's Y position is above Max or below Min and switch direction.
			if (transform.position.y > maxY)
				Dir = -1f;
			else if (transform.position.y < minY)
				Dir = 1f;

			//Compute new position based on VerticalSpeed and whether we are going up or down
			Vector3 NewPos = new Vector3 (transform.position.x, transform.position.y + Random.Range (minY, maxY) + ((VerticalSpeed * Time.deltaTime) * Dir), transform.position.z);
			transform.position = NewPos;
		
		}
	}

	private void Reset(){
	//	float ypos = Random.Range (minY, maxY);
	//	float xpos = Random.Range (5.3f, 12f);
	//	_currentPosition = new Vector2 (xpos, ypos);
	//	_transform.position = _currentPosition;

			direction = 3;
			_transform.localScale = new Vector2 (direction, 3);
			_currentPosition = new Vector2 (direction*3f, 0f);
			_transform.position = _currentPosition;

	}

}