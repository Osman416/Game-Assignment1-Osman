﻿using UnityEngine;
using System.Collections;

public class EnemyShooting : MonoBehaviour {

	public Vector3 bulletOffset = new Vector3(0, 1f, 0);

	public GameObject bulletpf;
	int bulletLayer;

	public float fireDelay = 0.2f;
	float cooldownTimer = 0;

	Transform Player;


	void Start() {
		bulletLayer = gameObject.layer;
	}

	// Update is called once per frame
	void Update () {

			if(Player == null) {
				// Find the players ship
				GameObject go = GameObject.FindWithTag ("Player");

				if(go != null) {
					Player = go.transform;
				}

			}


		cooldownTimer -= Time.deltaTime;

		if( cooldownTimer <= 0 && bulletpf != null && Player != null && Vector3.Distance(transform.position, Player.position) < 10) {
			// SHOOT!
			Debug.Log ("enemy shot bullet");
			cooldownTimer = fireDelay;

			Vector3 offset = transform.rotation * bulletOffset;

			GameObject bulletGO = (GameObject)Instantiate(bulletpf, transform.position + offset, transform.rotation);
			bulletGO.layer = bulletLayer;
		}
	}
}