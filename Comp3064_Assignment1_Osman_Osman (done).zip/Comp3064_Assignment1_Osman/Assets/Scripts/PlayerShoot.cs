﻿/*
Name: Osman Osman
I.D: 100962928
SrcName: Player Shooting (allows player to shoot) 
*/
using UnityEngine;
using UnityEngine;
using System.Collections;

public class PlayerShoot : MonoBehaviour {
	public AudioClip laser;
	public Vector3 bulletBal = new Vector3(0, 1f, 0);

	public GameObject bulletpf;
	int bulletLayer;
	GameObject explosion = null;
	public float fireDelay = 0.02f;
	float timer = 0;
	//public AudioClip Hit;


	void Start() {
		bulletLayer = gameObject.layer;
	}

	// Update is called once per frame
	void Update () {
		timer -= Time.deltaTime;

		if( Input.GetKeyDown(KeyCode.Space) && timer <= 0 ) {

			// Shoot Bullet
			Debug.Log ("player shot bullet");
			timer = fireDelay;

			Vector3 offset = transform.rotation * bulletBal;

			gameObject.GetComponent<AudioSource> ().Play ();
			GetComponent<AudioSource> ().playOnAwake = false;
			GetComponent<AudioSource> ().clip = laser;

			GameObject bulletGO = (GameObject)Instantiate(bulletpf, transform.position + offset, transform.rotation);
			bulletGO.layer = bulletLayer;
		}
	}
}
